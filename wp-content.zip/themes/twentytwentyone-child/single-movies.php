<?php
// single-movies.php
get_header();

while ( have_posts() ) : the_post();
    ?>
    <div class="movie-content">
        <?php the_content(); ?>
    </div>
    <div class="movie-title">
        <?php echo get_post_meta( get_the_ID(), 'movie_title', true ); ?>
    </div>
    <?php
endwhile;

get_footer();
