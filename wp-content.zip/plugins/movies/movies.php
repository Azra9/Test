<?php
/*
Plugin Name: Movies
*/

//Register Custom Post Type
function movies_register_post_type() {
    register_post_type( 'movies', array(
        'labels' => array(
            'name' => 'Movies',
            'singular_name' => 'Movie',
        ),
        'public' => true,
        'supports' => array( 'title', 'editor' ), 
        'show_in_rest' => true, // Enable REST API support
    ) );
}
add_action( 'init', 'movies_register_post_type' );

//Add Meta Box for Movie Title
function movies_add_meta_box() {
    add_meta_box(
        'movie_title_meta_box',
        'Movie Title',
        'movies_render_meta_box',
        'movies',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'movies_add_meta_box' );

function movies_render_meta_box( $post ) {
    $movie_title = get_post_meta( $post->ID, 'movie_title', true );
    ?>
    <label for="movie_title">Movie Title:</label>
    <input type="text" id="movie_title" name="movie_title" value="<?php echo esc_attr( $movie_title ); ?>">
    <?php
}

// Save Movie Title Meta Data
function movies_save_meta_data( $post_id ) {
    if ( isset( $_POST['movie_title'] ) ) {
        update_post_meta( $post_id, 'movie_title', sanitize_text_field( $_POST['movie_title'] ) );
    }
}
add_action( 'save_post', 'movies_save_meta_data' );

