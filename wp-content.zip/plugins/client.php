<?php

class QssApiClient {
    private $base_url = 'https://symfony-skeleton.q-tests.com/api/v2/token';
    private $email;
    private $password;

    public function __construct($email, $password) {
        $this->email = $email;
        $this->password = $password;
    }

    public function login() {
        $url = $this->base_url;

        $data = array(
            'email' => $this->email,
            'password' => $this->password
        );

        $options = array(
            'http' => array(
                'header' => "Content-type: application/json\r\n",
                'method' => 'POST',
                'content' => json_encode($data)
            )
        );

        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $response = json_decode($result, true);

        return $response['token_key'] ?? null;
    }
}
