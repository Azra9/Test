<?php
/*
Plugin Name: QSS API Login
*/

// Include the QssApiClient class
require_once plugin_dir_path( __FILE__ ) . 'client.php';

// Register a shortcode for the login page
function qss_login_shortcode() {
    ob_start();
    qss_login_form();
    return ob_get_clean();
}
add_shortcode( 'qss_login', 'qss_login_shortcode' );

// Function to display the login form
function qss_login_form() {
    ?>
    <form id="qss-login-form" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
    <?php
}

// Handle form submission
function qss_handle_login() {
    if ( isset( $_POST['email'] ) && isset( $_POST['password'] ) ) {
        $email = sanitize_email( $_POST['email'] );
        $password = sanitize_text_field( $_POST['password'] );

        $qss_api_client = new QssApiClient( $email, $password );

        $token = $qss_api_client->login();

        if ( $token ) {
           
            set_transient( 'qss_access_token', $token, HOUR_IN_SECONDS );
            $access_token = get_transient('qss_access_token');
            exit;
        } else {
            die('failed login');
        }
    }
}
add_action( 'init', 'qss_handle_login' );
